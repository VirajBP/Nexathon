import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
    Box, 
    Container, 
    Card, 
    CardContent, 
    Typography, 
    TextField,
    Grid,
    Drawer,
    List,
    ListItem,
    ListItemIcon,
    ListItemText,
    Divider,
    Button
} from '@mui/material';
import Sidebar from '../../Sidebar/Sidebar';  // Make sure you have this component
import './Market.css';
import { dummyProducts } from '../../../utils/dummyData';

const Market = () => {
    const [marketType, setMarketType] = useState('');
    const [searchQuery, setSearchQuery] = useState('');
    const [products, setProducts] = useState([]);
    const [recentListings, setRecentListings] = useState([]);
    const [loading, setLoading] = useState(false);
    const [filters, setFilters] = useState({
        minPrice: '',
        maxPrice: '',
        location: '',
        sortBy: 'latest',
        // Crop-specific filters
        organicOnly: false,
        quality: '',
        // Waste-specific filters
        moisture: '',
        transportRequired: false
    });
    const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

    // Fetch recent listings when market type changes
    useEffect(() => {
        if (marketType) {
            // Load dummy data based on market type
            setProducts(dummyProducts[marketType]);
            setRecentListings(dummyProducts[marketType].slice(0, 3));
        }
    }, [marketType]);

    const handleMarketSelect = async (type) => {
        setMarketType(type);
        try {
            setLoading(true);
            const response = await axios.get(`http://localhost:5000/api/products/${type}`);
            setProducts(response.data.data);
        } catch (error) {
            console.error('Error fetching products:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleSearch = (e) => {
        const query = e.target.value.toLowerCase();
        setSearchQuery(query);

        const filteredProducts = dummyProducts[marketType].filter(product => {
            const matchesSearch = 
                product.productName.toLowerCase().includes(query) ||
                product.productVariety.toLowerCase().includes(query) ||
                product.farmer.location.toLowerCase().includes(query);

            const matchesPrice = 
                (!filters.minPrice || product.price >= Number(filters.minPrice)) &&
                (!filters.maxPrice || product.price <= Number(filters.maxPrice));

            const matchesLocation = 
                !filters.location || 
                product.farmer.location.toLowerCase().includes(filters.location.toLowerCase());

            // Type-specific filtering
            if (marketType === 'crops') {
                if (filters.organicOnly && !product.organicCertified) return false;
                if (filters.quality && product.quality !== filters.quality) return false;
            } else {
                if (filters.moisture && product.moisture !== filters.moisture) return false;
                if (filters.transportRequired && !product.transportAvailable) return false;
            }

            return matchesSearch && matchesPrice && matchesLocation;
        });

        setProducts(filteredProducts);
    };

    const handleFilterChange = (e) => {
        setFilters({
            ...filters,
            [e.target.name]: e.target.value
        });
    };

    const renderTypeSpecificFilters = () => {
        if (marketType === 'crops') {
            return (
                <>
                    <div className="filter-group">
                        <label className="checkbox-label">
                            <input
                                type="checkbox"
                                checked={filters.organicOnly}
                                onChange={(e) => setFilters({
                                    ...filters,
                                    organicOnly: e.target.checked
                                })}
                            />
                            Organic Only
                        </label>
                    </div>
                    <select
                        name="quality"
                        value={filters.quality}
                        onChange={handleFilterChange}
                        className="filter-select"
                    >
                        <option value="">All Qualities</option>
                        <option value="Premium">Premium</option>
                        <option value="Standard">Standard</option>
                    </select>
                </>
            );
        } else {
            return (
                <>
                    <select
                        name="moisture"
                        value={filters.moisture}
                        onChange={handleFilterChange}
                        className="filter-select"
                    >
                        <option value="">All Moisture Levels</option>
                        <option value="10%">10%</option>
                        <option value="12%">12%</option>
                        <option value="15%">15%</option>
                    </select>
                    <div className="filter-group">
                        <label className="checkbox-label">
                            <input
                                type="checkbox"
                                checked={filters.transportRequired}
                                onChange={(e) => setFilters({
                                    ...filters,
                                    transportRequired: e.target.checked
                                })}
                            />
                            Transport Available
                        </label>
                    </div>
                </>
            );
        }
    };

    if (!marketType) {
        return (
            <div className="market-page">
                <Sidebar />
                <Container className="market-selection-container">
                    <Grid container spacing={4} justifyContent="center">
                        <Grid item xs={12} md={6}>
                            <Card 
                                className="market-type-card"
                                onClick={() => handleMarketSelect('crops')}
                            >
                                <img 
                                    src="/images/market/crops.jpg" 
                                    alt="Crops" 
                                    className="market-type-image"
                                />
                                <CardContent>
                                    <Typography variant="h5">
                                        Crops Market
                                    </Typography>
                                    <Typography variant="body2" color="textSecondary">
                                        Browse fresh crops directly from farmers
                                    </Typography>
                                </CardContent>
                            </Card>
                        </Grid>
                        <Grid item xs={12} md={6}>
                            <Card 
                                className="market-type-card"
                                onClick={() => handleMarketSelect('agriWaste')}
                            >
                                <img 
                                    src="/images/products/waste/wheat-straw.jpg" 
                                    alt="Agricultural Waste" 
                                    className="market-type-image"
                                />
                                <CardContent>
                                    <Typography variant="h5">
                                        Agricultural Waste Market
                                    </Typography>
                                    <Typography variant="body2" color="textSecondary">
                                        Find straw, husk, and other agricultural by-products
                                    </Typography>
                                </CardContent>
                            </Card>
                        </Grid>
                    </Grid>
                </Container>
            </div>
        );
    }

    return (
        <div className="market-page">
            <Sidebar 
                userType="consumer"
                onToggle={(collapsed) => setIsSidebarCollapsed(collapsed)}
            />
            <Container className={`market-container ${isSidebarCollapsed ? 'sidebar-collapsed' : ''}`}>
                {/* Search and Filter Section */}
                <Box className="search-section">
                    <TextField
                        fullWidth
                        variant="outlined"
                        placeholder={`Search ${marketType === 'crops' ? 'crops' : 'agricultural waste'}...`}
                        value={searchQuery}
                        onChange={handleSearch}
                        className="search-input"
                    />
                    <Box className="filters">
                        <TextField
                            name="minPrice"
                            label="Min Price"
                            type="number"
                            value={filters.minPrice}
                            onChange={handleFilterChange}
                            className="filter-input"
                        />
                        <TextField
                            name="maxPrice"
                            label="Max Price"
                            type="number"
                            value={filters.maxPrice}
                            onChange={handleFilterChange}
                            className="filter-input"
                        />
                        <TextField
                            name="location"
                            label="Location"
                            value={filters.location}
                            onChange={handleFilterChange}
                            className="filter-input"
                        />
                        <select
                            name="sortBy"
                            value={filters.sortBy}
                            onChange={handleFilterChange}
                            className="filter-select"
                        >
                            <option value="latest">Latest</option>
                            <option value="price_low">Price: Low to High</option>
                            <option value="price_high">Price: High to Low</option>
                        </select>
                        {renderTypeSpecificFilters()}
                    </Box>
                </Box>

                {/* Recent Listings Section */}
                {recentListings.length > 0 && (
                    <Box className="recent-listings">
                        <Typography variant="h6" className="section-title">
                            Recent Listings
                        </Typography>
                        <Grid container spacing={3}>
                            {recentListings.slice(0, 3).map((product) => (
                                <Grid item xs={12} sm={6} md={4} key={product._id}>
                                    <Card className="product-card recent">
                                        <img 
                                            src={`/images/products/${product.image}`}
                                            alt={product.productName}
                                            className="product-image"
                                            onError={(e) => {
                                                e.target.onerror = null;
                                                e.target.src = '/images/products/default.jpg';
                                            }}
                                        />
                                        <CardContent>
                                            <Typography variant="h6">
                                                {product.productName}
                                            </Typography>
                                            <Typography variant="body2" color="textSecondary">
                                                Quantity: {product.quantity}
                                            </Typography>
                                            <Typography variant="h6" color="primary">
                                                ₹{product.price}
                                            </Typography>
                                            <Typography variant="body2">
                                                Seller: {product.farmer.name}
                                            </Typography>
                                            <Typography variant="body2">
                                                Location: {product.farmer.location}
                                            </Typography>
                                            <Button 
                                                variant="contained" 
                                                color="primary"
                                                fullWidth
                                                className="view-details-btn"
                                            >
                                                View Details
                                            </Button>
                                        </CardContent>
                                    </Card>
                                </Grid>
                            ))}
                        </Grid>
                    </Box>
                )}

                {/* All Products Grid */}
                <Box className="all-products">
                    <Typography variant="h6" className="section-title">
                        All Available {marketType === 'crops' ? 'Crops' : 'Agricultural Waste'}
                    </Typography>
                    <Grid container spacing={3} className="products-grid">
                        {products.map((product) => (
                            <Grid item xs={12} sm={6} md={4} key={product._id}>
                                <Card className="product-card">
                                    <img 
                                        src={`/images/products/${product.image}`}
                                        alt={product.productName}
                                        className="product-image"
                                        onError={(e) => {
                                            e.target.onerror = null;
                                            e.target.src = '/images/products/default.jpg';
                                        }}
                                    />
                                    <CardContent>
                                        <Typography variant="h6">
                                            {product.productName}
                                        </Typography>
                                        <Typography variant="body2" color="textSecondary">
                                            Quantity: {product.quantity}
                                        </Typography>
                                        <Typography variant="h6" color="primary">
                                            ₹{product.price}
                                        </Typography>
                                        <Typography variant="body2">
                                            Seller: {product.farmer.name}
                                        </Typography>
                                        <Typography variant="body2">
                                            Location: {product.farmer.location}
                                        </Typography>
                                        <Button 
                                            variant="contained" 
                                            color="primary"
                                            fullWidth
                                            className="view-details-btn"
                                        >
                                            View Details
                                        </Button>
                                    </CardContent>
                                </Card>
                            </Grid>
                        ))}
                    </Grid>
                </Box>
            </Container>
        </div>
    );
};

export default Market; 