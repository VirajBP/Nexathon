import { useState, useEffect } from "react";
import Sidebar from '../../Sidebar/Sidebar';
import './Orders.css';

export default function ConsumerOrders() {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [orders, setOrders] = useState([
    { 
      id: 1, 
      name: "Wheat", 
      status: "Pending",
      quantity: "50 kg",
      price: "₹2000",
      farmerName: "Rajesh Kumar",
      orderDate: "2024-03-20",
      expectedDelivery: "2024-03-25"
    },
    { 
      id: 2, 
      name: "Rice", 
      status: "Completed",
      quantity: "30 kg",
      price: "₹1800",
      farmerName: "Suresh Verma",
      orderDate: "2024-03-15",
      deliveryDate: "2024-03-18"
    },
    { 
      id: 3, 
      name: "Corn", 
      status: "Rejected",
      quantity: "25 kg",
      price: "₹1200",
      farmerName: "Amit Sharma",
      orderDate: "2024-03-10",
      deliveryDate: "2024-03-12"
    },
  ]);

  const [visibleOrders, setVisibleOrders] = useState([]);

  useEffect(() => {
    setTimeout(() => {
      setVisibleOrders(orders);
    }, 300);
  }, [orders]);

  return (
    <div className="dashboard-container">
      <Sidebar 
        userType="consumer" 
        onToggle={(collapsed) => setIsSidebarCollapsed(collapsed)}
      />
      <div className={`dashboard-content ${isSidebarCollapsed ? 'sidebar-collapsed' : ''}`}>
        <h1 className="orders-heading">Pending Orders</h1>
        <div className="table-container">
          <table className="orders-table">
            <thead>
              <tr>
                <th>Order ID</th>
                <th>Product</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Farmer</th>
                <th>Order Date</th>
                <th>Expected Delivery</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {visibleOrders.filter(order => order.status === "Pending").map((order, index) => (
                <tr key={order.id} className="order-row animate" style={{ animationDelay: `${index * 0.1}s` }}>
                  <td>#{order.id}</td>
                  <td>{order.name}</td>
                  <td>{order.quantity}</td>
                  <td>{order.price}</td>
                  <td>{order.farmerName}</td>
                  <td>{order.orderDate}</td>
                  <td>{order.expectedDelivery}</td>
                  <td>
                    <span className="status-badge status-pending">
                      {order.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <h1 className="orders-heading">Past Orders</h1>
        <div className="table-container">
          <table className="orders-table">
            <thead>
              <tr>
                <th>Order ID</th>
                <th>Product</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Farmer</th>
                <th>Order Date</th>
                <th>Delivery Date</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {visibleOrders.filter(order => order.status !== "Pending").map((order, index) => (
                <tr key={order.id} className="order-row animate" style={{ animationDelay: `${index * 0.1}s` }}>
                  <td>#{order.id}</td>
                  <td>{order.name}</td>
                  <td>{order.quantity}</td>
                  <td>{order.price}</td>
                  <td>{order.farmerName}</td>
                  <td>{order.orderDate}</td>
                  <td>{order.deliveryDate}</td>
                  <td>
                    <span className={`status-badge status-${order.status.toLowerCase()}`}>
                      {order.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
} 