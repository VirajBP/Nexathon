const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const Farmer = require('../Model/Farmer');
const Consumer = require('../Model/Consumer');

// Validation helper
const validateEmail = (email) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
};

exports.register = async (req, res) => {
    try {
        const userType = req.path.includes('farmer') ? 'farmer' : 'consumer';
        console.log('Registration attempt for:', userType, req.body);

        if (userType === 'farmer') {
            const { name, phoneNumber, password, location } = req.body;

            let farmer = await Farmer.findOne({ phoneNumber });
            if (farmer) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Phone number already registered' 
                });
            }

            const salt = await bcrypt.genSalt(10);
            const hashedPassword = await bcrypt.hash(password, salt);

            farmer = new Farmer({
                name,
                phoneNumber,
                password: hashedPassword,
                location
            });

            await farmer.save();

            const token = jwt.sign(
                { user: { id: farmer.id, type: 'farmer' } },
                process.env.JWT_SECRET,
                { expiresIn: '24h' }
            );

            res.status(201).json({
                success: true,
                data: {
                    token,
                    user: {
                        id: farmer.id,
                        name: farmer.name,
                        phoneNumber: farmer.phoneNumber,
                        location: farmer.location,
                        type: 'farmer'
                    }
                }
            });

        } else {
            const { name, email, password, location, phoneNumber, type } = req.body;
            
            let consumer = await Consumer.findOne({ email });
            if (consumer) {
                return res.status(400).json({ 
                    success: false, 
                    message: 'Email already registered' 
                });
            }

            const salt = await bcrypt.genSalt(10);
            const hashedPassword = await bcrypt.hash(password, salt);

            consumer = new Consumer({
                name,
                email,
                password: hashedPassword,
                location,
                phoneNumber,
                type
            });

            await consumer.save();

            const token = jwt.sign(
                { user: { id: consumer.id, type: 'consumer' } },
                process.env.JWT_SECRET,
                { expiresIn: '24h' }
            );

            res.status(201).json({
                success: true,
                data: {
                    token,
                    user: {
                        id: consumer.id,
                        name: consumer.name,
                        email: consumer.email,
                        location: consumer.location,
                        phoneNumber: consumer.phoneNumber,
                        type: consumer.type
                    }
                }
            });
        }
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Server error during registration' 
        });
    }
};

exports.login = async (req, res) => {
    try {
        const { userType } = req.body;
        console.log('Login attempt for:', userType, req.body);

        if (userType === 'farmer') {
            const { phoneNumber, password } = req.body;
            
            const farmer = await Farmer.findOne({ phoneNumber });
            if (!farmer) {
                return res.status(401).json({ 
                    success: false, 
                    message: 'Invalid credentials' 
                });
            }

            const isMatch = await bcrypt.compare(password, farmer.password);
            if (!isMatch) {
                return res.status(401).json({ 
                    success: false, 
                    message: 'Invalid credentials' 
                });
            }

            const token = jwt.sign(
                { user: { id: farmer.id, type: 'farmer' } },
                process.env.JWT_SECRET,
                { expiresIn: '24h' }
            );

            res.json({
                success: true,
                data: {
                    token,
                    user: {
                        id: farmer.id,
                        name: farmer.name,
                        phoneNumber: farmer.phoneNumber,
                        location: farmer.location,
                        type: 'farmer'
                    }
                }
            });

        } else {
            const { email, password } = req.body;
            
            const consumer = await Consumer.findOne({ email });
            if (!consumer) {
                return res.status(401).json({ 
                    success: false, 
                    message: 'Invalid credentials' 
                });
            }

            const isMatch = await bcrypt.compare(password, consumer.password);
            if (!isMatch) {
                return res.status(401).json({ 
                    success: false, 
                    message: 'Invalid credentials' 
                });
            }

            const token = jwt.sign(
                { user: { id: consumer.id, type: 'consumer' } },
                process.env.JWT_SECRET,
                { expiresIn: '24h' }
            );

            res.json({
                success: true,
                data: {
                    token,
                    user: {
                        id: consumer.id,
                        name: consumer.name,
                        email: consumer.email,
                        location: consumer.location,
                        phoneNumber: consumer.phoneNumber,
                        type: consumer.type
                    }
                }
            });
        }
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Server error during login' 
        });
    }
};

module.exports = exports; 